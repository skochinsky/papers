Included here are few of the programs mentioned in my presentation at 
Recon and some extra stuff.

cramfs - cramfsck and mkcramfs compiled for Windows. This includes 
my modification to dump the permissions/attributes to a file which can 
then be used to recreate the filesystem.

JFFS2 - unpack_jffs2.py script to unpack JFFS2 images. I also included 
some source files from U-Boot that I used to develop this script.

JTAG Search - a JTAG pinout detector. Can brute-force the JTAG pinout 
using GPIOs of a microcontroller. The included version was made for mbed 
platform, but should be easily portable.

kallsyms - IDAPython script to dump the new format kallsyms tables from a Linux 
kernel image. You will need to identify and name some of the key locations 
in the kernel before using it (see the source for details).

SquashFS - unsquashfs and mksquashfs compiled for Windows.

uImage   - Das U-Boot image loader for IDA Pro (needs IDA 5.6 or later).
 
YAFFS    - unyaffs compiled for Windows.

2010-07-23
Igor Skochinsky
skochinsky@gmail.com
