These are squashfs-tools compiled for windows by Nikolay Pelov (www.nicksoft.info)
Put cygwin1.dll in squashfs tools directory or windows system directory before using .exe binaries.
