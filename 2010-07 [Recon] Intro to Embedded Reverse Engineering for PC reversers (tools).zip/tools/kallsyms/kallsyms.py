# Linux kernel kallsyms unpacker
# Version 0.1
# Copyright (c) 2010 Igor Skochinsky
#
# This software is provided 'as-is', without any express or implied
# warranty. In no event will the authors be held liable for any damages
# arising from the use of this software.
#
# Permission is granted to anyone to use this software for any purpose,
# including commercial applications, and to alter it and redistribute it
# freely, subject to the following restrictions:
#
#    1. The origin of this software must not be misrepresented; you must not
#    claim that you wrote the original software. If you use this software
#    in a product, an acknowledgment in the product documentation would be
#    appreciated but is not required.
#
#    2. Altered source versions must be plainly marked as such, and must not be
#    misrepresented as being the original software.
#
#    3. This notice may not be removed or altered from any source
#    distribution.

def do_kallsyms(do_rename, do_dump):
  token_idxs = LocByName("kallsyms_token_index")
  tokens = LocByName("kallsyms_token_table")
  names = LocByName("kallsyms_names")
  addrs = LocByName("kallsyms_addresses")
  namecnt = LocByName("kallsyms_num_syms")
  if namecnt == BADADDR:
    Warning("kallsyms_num_syms is not defined!");
    return
  namecnt = Dword(namecnt)
  if tokens == BADADDR:
    Warning("kallsyms_token_table is not defined!");
    return
  if token_idxs == BADADDR:
    Warning("kallsyms_token_index is not defined!");
    return
  if names == BADADDR:
    Warning("kallsyms_names is not defined!");
    return
  if addrs == BADADDR:
    Warning("kallsyms_addresses is not defined!");
    return
  nametbl = []
  tokentbl = []
  for i in range(256):
    idx = Word(token_idxs+i*2)
    token = GetString(tokens+idx, -1, 0)
    #print "token %d: %s"%(i, token)
    if token == None: token=""
    tokentbl.append(token)

  if do_dump:
    dump = file("ksym","w")
  if names != BADADDR:
    for i in range(namecnt):
      nlen = Byte(names)
      names += 1
      name = ""
      while nlen>0:
        j = Byte(names)
        #print "j: %d, token: %s"%(j, tokentbl[j])
        name += tokentbl[j]
        names += 1
        nlen -= 1
      #print "Name %d: %s"%(i, name)
      #nametbl.append(name)
      addr = Dword(addrs+i*4)
      if do_dump:
        dump.write("%08X %s %s\n"%(addr, name[0], name[1:]))
      if do_rename and name.find(".") == -1:
        #print "%08X: %s"%(addr, name[1:])
        if isTail(GetFlags(addr)):
          MakeUnkn(addr, DOUNK_SIMPLE)
        MakeNameEx(addr, name[1:], SN_NOWARN)
  
  if do_dump:
    dump.close()

# you will need to find the kallsyms_num_syms value in the kernel image
# and all other tables mentioned below
# consult kallsyms.c from the kernel sources
# after that the script can parse the tables and create the symbols list

#a = 0xC0267D70 
#MakeName(a, "kallsyms_num_syms")
#n = Dword(a)
#b = (a - n*4) & ~0xF
#MakeName(b, "kallsyms_addresses")
#b = (a + 16) & ~0xF
#MakeName(b, "kallsyms_names")


#MakeName(0xC0267D70, "kallsyms_num_syms")
#MakeName(0xC022C460, "kallsyms_addresses")
#MakeName(0xC023B290, "kallsyms_num_syms")
#MakeName(0xC023B2A0, "kallsyms_names")
#MakeName(0xC0261FE0, "kallsyms_token_table")
#MakeName(0xC0262370, "kallsyms_token_index")
do_kallsyms(True, True)
